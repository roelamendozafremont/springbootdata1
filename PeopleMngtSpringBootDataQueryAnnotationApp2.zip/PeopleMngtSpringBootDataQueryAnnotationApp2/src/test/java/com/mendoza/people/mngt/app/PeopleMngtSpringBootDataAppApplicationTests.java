package com.mendoza.people.mngt.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopleMngtSpringBootDataAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
